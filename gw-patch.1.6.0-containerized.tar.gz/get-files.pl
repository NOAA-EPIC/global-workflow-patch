#!/usr/bin/perl
  @lines = split(/\n/,`( git status && git submodule foreach --recursive git status )`);
  $count = 0;
  $untracked = 0;
  $directory = ".";
  open(FH, '>', "filelist.txt") or die $!;
  foreach(@lines) {
    $line = $_;
    if($line =~ /Entering/) {
      @words = split(/\'/,$line);
      $directory = @words[1];
    }
    if($line =~ /modified:/) {
      $line =~ s/\s+//g;
      @words = split(/:/,$line);
      $change = @words[1];
      if($change !~ /content/) {
        print FH "$directory/$change\n";
      }
    }
    if($line =~ /Untracked/) {
      $untracked = 1;
      $count = 0;
    } else {
      $count++;
    }
    if(($untracked == 1) && ($count > 1)) {
       @words=split(/\s+/,$line);
       $file = @words[1];
       if($file =~ /changes/){
         $untracked = 0;
       } else {
         if($file ne "") {
           print FH "$directory/$file\n";
         }
       }
    }
     
  }
  system("tar cvfz gw-patch.tar.gz -T filelist.txt");
