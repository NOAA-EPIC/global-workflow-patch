-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2025-02-11 09:56:53.923628
--
-- global-workflow-env@1.0.0%intel@2021.10.0+python build_system=bundle arch=linux-ubuntu22.04-core2/v7gitkg
--

whatis([[Name : global-workflow-env]])
whatis([[Version : 1.0.0]])
whatis([[Target : core2]])
whatis([[Short description : Development environment for NOAA's Global Workflow]])

help([[Name   : global-workflow-env]])
help([[Version: 1.0.0]])
help([[Target : core2]])
help()
help([[Development environment for NOAA's Global Workflow]])


depends_on("bacio/2.4.1")
depends_on("bufr/12.1.0")
depends_on("cdo/2.3.0")
depends_on("crtm/3.1.1-build1")
depends_on("esmf/8.6.1")
depends_on("g2/3.5.1")
depends_on("g2tmpl/1.13.0")
--depends_on("gh/2.58.0")
depends_on("glibc/2.35")
depends_on("grib-util/1.4.0")
depends_on("gsi-ncdiag/1.1.2")
depends_on("ip/5.1.0")
depends_on("landsfcutil/2.4.2")
depends_on("met/11.1.1")
depends_on("metplus/5.1.0")
depends_on("ncio/1.1.2")
depends_on("nco/5.2.4")
depends_on("nemsio/2.5.4")
depends_on("nemsiogfs/2.5.3")
depends_on("netcdf-c/4.9.2")
depends_on("netcdf-fortran/4.6.1")
depends_on("prod_util/2.1.1")
depends_on("py-wxflow/0.2.0")
depends_on("sigio/2.3.3")
depends_on("ufs-pyenv/1.0.0")
depends_on("w3emc/2.10.0")
depends_on("w3nco/2.4.1")
depends_on("wgrib2/3.5.0")

prepend_path("CMAKE_PREFIX_PATH", "/opt/spack-stack/spack-stack-1.9.0/envs/unified-env/install/intel/2021.10.0/global-workflow-env-1.0.0-v7gitkg/.", ":")
setenv("global_workflow_env_ROOT", "/opt/spack-stack/spack-stack-1.9.0/envs/unified-env/install/intel/2021.10.0/global-workflow-env-1.0.0-v7gitkg")

